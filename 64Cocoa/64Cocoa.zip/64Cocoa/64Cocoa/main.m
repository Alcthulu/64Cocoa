//
//  main.m
//  64Cocoa
//
//  Created by Alvaro Rosa on 13/12/2019.
//  Copyright © 2019 AlvaroRosaARG. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
