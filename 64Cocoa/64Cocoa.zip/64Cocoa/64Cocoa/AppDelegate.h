//
//  AppDelegate.h
//  64Cocoa
//
//  Created by Alvaro Rosa on 13/12/2019.
//  Copyright © 2019 AlvaroRosaARG. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

